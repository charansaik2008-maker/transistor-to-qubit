"""Quick self-checks:  python tests.py"""
import numpy as np
from tq import quantum as qu, logic, transistor as tr, noise as nz

# Level 2: transistor NOT gate and X gate
assert tr.to_bit(tr.inverter(0.0)) == 1 and tr.to_bit(tr.inverter(5.0)) == 0
# Level 3: Hadamard gives 50/50
s, _ = qu.simulate(1, [("h", 0, ())]); assert np.allclose(qu.probabilities(s), [.5, .5])
# H Z H = X
s, _ = qu.simulate(1, [("h", 0, ()), ("z", 0, ()), ("h", 0, ())]); assert np.allclose(qu.probabilities(s), [0, 1])
# Bell state
s, _ = qu.simulate(2, [("h", 0, ()), ("cx", 1, (0,))]); assert np.allclose(qu.probabilities(s), [.5, 0, 0, .5])
# Level 4: classical gates == quantum implementations
for name in qu.EQUIVALENTS:
    for a in (0, 1):
        for b in (0, 1):
            assert qu.run_equivalent(name, a, b)[0] == logic.GATES[name](a, b), (name, a, b)
# NAND universality
for g in ("NOT", "AND", "OR", "NOR", "XOR"):
    for a in (0, 1):
        for b in (0, 1):
            assert logic.from_nand(g, a, b) == logic.GATES[g](a, b)
# noise: depolarising keeps trace 1 and QEC beats no coding at small p
r = nz.experiment("zero", "depolarizing", .3); assert abs(r["p0"] + r["p1"] - 1) < 1e-9
ana, _ = nz.repetition_code(np.array([.1])); assert ana[0] < .1
print("All tests passed  |  Qiskit available:", qu.HAVE_QISKIT)
