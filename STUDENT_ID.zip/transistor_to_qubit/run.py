"""Start the website:  python run.py [port]"""
import sys
from tq.server import serve

if __name__ == "__main__":
    serve(port=int(sys.argv[1]) if len(sys.argv) > 1 else 8000)
