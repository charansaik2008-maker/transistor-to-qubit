"""Minimal web server using only the Python standard library."""
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import pages

ROUTES = {"/": pages.home, "/transistor": pages.transistor, "/qubit": pages.qubit,
          "/compare": pages.compare, "/circuit": pages.circuit}


class Handler(BaseHTTPRequestHandler):
    def _send(self, html, code=200):
        data = html.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        try:
            if u.path == "/quiz":
                return self._send(pages.quiz_form(q, q.get("student", [""])[0], q.get("mode", ["pre"])[0]))
            fn = ROUTES.get(u.path.rstrip("/") or "/")
            if fn:
                return self._send(fn(q))
            self._send("<h1>404</h1><a href='/'>Home</a>", 404)
        except Exception as e:  # keep the classroom demo alive
            self._send(f"<h1>Error</h1><pre>{type(e).__name__}: {e}</pre><a href='/'>Home</a>", 500)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        form = urllib.parse.parse_qs(self.rfile.read(n).decode("utf-8"))
        if self.path == "/quiz":
            return self._send(pages.quiz_result(form))
        self._send("<h1>404</h1>", 404)

    def log_message(self, fmt, *args):
        pass


def serve(host="127.0.0.1", port=8000):
    srv = ThreadingHTTPServer((host, port), Handler)
    print(f"Transistor-to-Qubit site running at http://{host}:{port}  (Ctrl+C to stop)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
