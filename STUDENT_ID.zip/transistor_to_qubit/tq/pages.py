"""Page builders. Each function takes a dict of query params and returns HTML."""
from html import escape
import numpy as np

from . import transistor as tr, logic, quantum as qu, noise as nz, quiz as qz, svg
from .layout import page, num, select


def _f(q, key, default, lo=None, hi=None):
    try:
        v = float(q.get(key, [default])[0] if isinstance(q.get(key), list) else q.get(key, default))
    except (TypeError, ValueError):
        v = default
    if lo is not None:
        v = max(lo, v)
    if hi is not None:
        v = min(hi, v)
    return v


def _s(q, key, default):
    v = q.get(key, default)
    return v[0] if isinstance(v, list) else v


# ------------------------------------------------------------------ HOME
def home(q):
    cards = [("/transistor", "1 \u00b7 Transistor", "Levels 1-2 / Modules A & B: switch an LED with a BJT, build a NOT gate, explore logic gates."),
             ("/qubit", "2 \u00b7 Bit \u2192 Qubit", "Level 3 / Module C: amplitudes, superposition, Hadamard, Bloch vector, measurement."),
             ("/compare", "3 \u00b7 Comparison", "Module D: classical vs quantum table and the noise study (bit/phase flip, depolarizing, error correction)."),
             ("/circuit", "4 \u00b7 Circuit Lab", "Level 4: same function as a classical gate and as a Qiskit circuit; build your own circuit."),
             ("/quiz", "Quiz", "Pre- and post-learning assessment with normalised learning gain.")]
    tiles = "".join(f'<a class="card" href="{h}" style="text-decoration:none;color:inherit"><h3 style="margin-top:0">{t}</h3><span class="mut">{d}</span></a>' for h, t, d in cards)
    eng = f"Qiskit {qu.QISKIT_VERSION} detected" if qu.HAVE_QISKIT else "Qiskit not installed - running the NumPy fallback (install qiskit for the full engine)"
    body = f"""<h2>Start with the electronics you know, move to qubits</h2>
<p>This site implements the <b>Transistor-to-Qubit Learning Framework</b>: a four-level path
<b>Transistor \u2192 Logic gate \u2192 Bit \u2192 Qubit \u2192 Classical vs Quantum circuit</b>, with an
interactive simulator for every step.</p>
<div class="flow"><span class="node">Transistor</span><span class="arrow">\u2192</span><span class="node">Logic gate</span><span class="arrow">\u2192</span>
<span class="node">Bit \u2192 Qubit</span><span class="arrow">\u2192</span><span class="node">Classical vs Quantum circuit</span></div>
<div class="grid2">{tiles}</div>
<div class="card"><h3 style="margin-top:0">Concept map (Classical \u2192 Quantum)</h3>
<table><tr><th>Electronics concept</th><th>Student already knows</th><th>Quantum counterpart</th></tr>
<tr><td>Transistor</td><td>Electronic switching device</td><td>Qubit as quantum information unit</td></tr>
<tr><td>ON/OFF</td><td>0 / 1</td><td>Measurement gives 0 or 1</td></tr>
<tr><td>Voltage/current state</td><td>Physical representation of information</td><td>Quantum state / amplitude</td></tr>
<tr><td>Logic gate</td><td>AND, OR, NOT</td><td>X, Y, Z, H, CNOT gates</td></tr>
<tr><td>NOT gate</td><td>Inverts 0 \u2194 1</td><td>X gate performs quantum bit flip</td></tr>
<tr><td>Digital circuit</td><td>Combination of logic gates</td><td>Quantum circuit</td></tr>
<tr><td>Noise</td><td>Disturbs transistor signal</td><td>Decoherence / quantum noise</td></tr>
<tr><td>Measurement</td><td>Reading circuit output</td><td>Quantum measurement</td></tr></table></div>
<p class="mut">Engine status: {eng}.</p>"""
    return page("Home", "/", body)


# ------------------------------------------------------------ TRANSISTOR
def transistor(q):
    vin = _f(q, "vin", 0.0, 0, 12)
    vcc = _f(q, "vcc", 5.0, 1, 24)
    rb = _f(q, "rb", 10000, 100, 1e6)
    rc = _f(q, "rc", 330, 10, 1e5)
    vth = _f(q, "vth", 0.7, 0.1, 3)
    beta = _f(q, "beta", 100, 10, 500)
    r = tr.led_switch(vin, vcc, rb, rc, beta, vth)
    glow = int(40 + 215 * r["brightness"])
    led_color = f"rgb({glow},{int(glow*0.15)},{int(glow*0.15)})" if r["brightness"] > 0 else "#555"
    ctl = f"""<form class="ctl" method="get" action="/transistor">
{num('vin','Base/gate voltage Vin (V)',vin,'0.1')}{num('vcc','Vcc (V)',vcc,'0.5')}{num('rb','Base resistor Rb (\u03a9)',int(rb),'100')}
{num('rc','Load resistance Rc (\u03a9)',int(rc),'10')}{num('vth','Switching threshold (V)',vth,'0.05')}{num('beta','Gain \u03b2',int(beta),'10')}
<button>Simulate</button></form>"""
    # sweep: Vin vs Ic and LED brightness
    vs = np.linspace(0, min(vcc, 5.0) if vcc > 5 else vcc, 80)
    ic = [tr.led_switch(v, vcc, rb, rc, beta, vth)["ic"] * 1000 for v in vs]
    sweep = svg.line_chart([("Collector current Ic (mA)", list(vs), ic)], "Vin (V)", "Ic (mA)")

    # Level 2: NOT gate
    rc_n = _f(q, "rcn", 1000, 100, 1e5)
    v, vo = tr.transfer_curve(vcc, rb, rc_n, beta, vth)
    nm = tr.noise_margins(vcc, rb, rc_n, beta, vth)
    rows = "".join(f"<tr><td>{a}</td><td class='num'>{x:.2f} V</td><td class='num'>{tr.inverter(x, vcc, rb, rc_n, beta, vth):.2f} V</td>"
                   f"<td><b>{tr.to_bit(tr.inverter(x, vcc, rb, rc_n, beta, vth), vcc)}</b></td></tr>" for a, x in ((0, 0.0), (1, vcc)))
    notg = f"""<h3>Level 2 \u2014 Transistor NOT gate</h3>
<p>A common-emitter stage inverts: <code>0\u21921</code> and <code>1\u21920</code>. The quantum equivalent is the
X gate: <code>X|0\u27e9=|1\u27e9</code>, <code>X|1\u27e9=|0\u27e9</code>.</p>
<div class="grid2"><div><table><tr><th>Input bit</th><th>Vin</th><th>Vout</th><th>Output bit</th></tr>{rows}</table>
<p class="mut">Noise margins: high = {nm['nm_high']:.2f} V, low = {nm['nm_low']:.2f} V (logic threshold Vcc/2).</p></div>
<div>{svg.line_chart([("Vout", list(v), list(vo))], "Vin (V)", "Vout (V)", hline=vcc/2)}</div></div>"""

    # Module B
    gname = _s(q, "gate", "NAND")
    if gname not in logic.GATES:
        gname = "NAND"
    tt = "".join(
        f"<tr>{''.join(f'<td>{x}</td>' for x in inp)}<td><b>{out}</b></td><td>{logic.from_nand(gname, *inp) if len(inp)==2 else logic.from_nand(gname, inp[0])}</td></tr>"
        for inp, out in logic.truth_table(gname))
    head = "<th>A</th>" if gname == "NOT" else "<th>A</th><th>B</th>"
    gsel = select("gate", "Gate", [(g, g) for g in logic.GATES], gname)
    modb = f"""<h3>Module B \u2014 Logic-gate simulator</h3>
<form class="ctl" method="get" action="/transistor">{gsel}<input type="hidden" name="vin" value="{vin}"><button>Show truth table</button></form>
<table style="margin-top:10px"><tr>{head}<th>{gname}</th><th>Built from NAND only</th></tr>{tt}</table>
<p class="mut">Static-CMOS cost: {logic.CMOS_TRANSISTORS[gname]} transistors \u00b7 NAND-only network: {logic.NAND_COUNT[gname]} NAND gate(s). The last column always equals the gate output \u2014 NAND is universal.</p>"""

    body = f"""<h2>1 \u00b7 Transistor</h2>
<div class="card"><h3 style="margin-top:0">Level 1 \u2014 Transistor as a switch (Module A)</h3>
<div class="flow"><span class="node">Input (Vin)</span><span class="arrow">\u2192</span><span class="node">Transistor</span><span class="arrow">\u2192</span><span class="node">LED</span></div><br>
{ctl}
<div class="grid2" style="margin-top:14px"><div>
<p><span class="led" style="background:{led_color};box-shadow:0 0 {int(30*r['brightness'])}px {led_color}"></span>
&nbsp; LED is <b>{'ON' if r['led_on'] else 'OFF'}</b> &nbsp;<span class="pill {'on' if r['led_on'] else 'off'}">{r['region']}</span></p>
<table><tr><th>Quantity</th><th>Value</th></tr><tr><td>Base current Ib</td><td class="num">{r['ib']*1e6:.1f} \u00b5A</td></tr>
<tr><td>Collector current Ic</td><td class="num">{r['ic']*1e3:.2f} mA</td></tr><tr><td>Vce</td><td class="num">{r['vce']:.2f} V</td></tr></table>
<p>Vin = {vin:g} V \u2192 <b>{'1' if r['bit'] else '0'}</b> &nbsp;\u21d2 &nbsp;0/1 \u2192 <b>classical bit</b></p></div>
<div>{sweep}</div></div></div>
<div class="card">{notg}</div><div class="card">{modb}</div>"""
    return page("Transistor", "/transistor", body)


# ---------------------------------------------------------------- QUBIT
GATE_WORDS = {"X", "Y", "Z", "H", "S", "T"}


def qubit(q):
    init = _s(q, "init", "0")
    gates_raw = _s(q, "gates", "H")
    shots = int(_f(q, "shots", 1000, 1, 100000))
    theta = _f(q, "theta", 90, 0, 180)
    phi = _f(q, "phi", 0, 0, 360)
    gates = [g.strip().upper() for g in gates_raw.replace(" ", ",").split(",") if g.strip()]
    bad = [g for g in gates if g not in GATE_WORDS]
    gates = [g for g in gates if g in GATE_WORDS][:12]
    start = {"0": np.array([1, 0], complex), "1": np.array([0, 1], complex),
             "custom": qu.single_qubit_state(theta, phi)}.get(init, np.array([1, 0], complex))
    ops = [(g.lower(), 0, ()) for g in gates]
    state, engine = qu.simulate(1, ops, init=start)
    a, b = state
    p = qu.probabilities(state)
    counts = qu.measure(state, 1, shots, seed=42)
    bx, by, bz = qu.bloch(state)
    inits = [("0", "|0\u27e9"), ("1", "|1\u27e9"), ("custom", "custom (\u03b8, \u03c6)")]
    ctl = f"""<form class="ctl" method="get" action="/qubit">{select('init','Initial state',inits,init)}
{num('theta','\u03b8 (deg, custom)',theta)}{num('phi','\u03c6 (deg, custom)',phi)}
<label>Gate sequence (X,Y,Z,H,S,T)<input name="gates" value="{escape(gates_raw)}" size="14"></label>{num('shots','Shots',shots,'1')}<button>Run</button></form>
<p class="mut">Presets: <a href="/qubit?init=0&gates=X">X|0\u27e9</a> \u00b7 <a href="/qubit?init=0&gates=H">H|0\u27e9</a> \u00b7
<a href="/qubit?init=0&gates=H,Z,H">H Z H</a> (interference) \u00b7 <a href="/qubit?init=0&gates=H,H">H H</a></p>"""
    warn = f'<p class="bad">Ignored unknown gates: {escape(", ".join(bad))}</p>' if bad else ""
    ideal_rows = "".join(f"<tr><td>|{qu.label(i,1)}\u27e9</td><td class='num'>{qu.fmt_c(state[i])}</td><td class='num'>{p[i]*100:.1f}%</td>"
                         f"<td class='num'>{counts.get(qu.label(i,1),0)/shots*100:.1f}%</td></tr>" for i in (0, 1))
    hist = svg.bar_chart(["0", "1"], [counts.get("0", 0) / shots, counts.get("1", 0) / shots], ylabel="Measured frequency", color="#7c3aed")
    ideal = svg.bar_chart(["0", "1"], list(p), ylabel="Ideal probability")
    body = f"""<h2>2 \u00b7 Bit \u2192 Qubit</h2>
<div class="grid2">
<div class="card"><h3 style="margin-top:0">Level 3 \u2014 the key conceptual difference</h3>
<table><tr><th>Transistor</th><td>ON or OFF</td></tr><tr><th>Classical bit</th><td>b \u2208 {{0, 1}}</td></tr>
<tr><th>Qubit</th><td>|\u03c8\u27e9 = \u03b1|0\u27e9 + \u03b2|1\u27e9 &nbsp;with |\u03b1|\u00b2 + |\u03b2|\u00b2 = 1</td></tr></table>
<p class="mut">A bit is a point in {{0,1}}. A qubit is a point on the Bloch sphere; measuring it gives 0 with probability |\u03b1|\u00b2 and 1 with |\u03b2|\u00b2.</p></div>
<div class="card"><h3 style="margin-top:0">Hadamard gate</h3><p><code>H|0\u27e9 = (|0\u27e9 + |1\u27e9)/\u221a2</code> \u21d2 P(0)=50%, P(1)=50%.</p>
<p class="mut">Try <b>H Z H</b>: the amplitudes interfere and the result is <code>|1\u27e9</code> with certainty \u2014 something no probabilistic classical bit can do.</p></div></div>
<div class="card"><h3 style="margin-top:0">Module C \u2014 single-qubit simulator</h3>{ctl}{warn}
<div class="grid2" style="margin-top:12px"><div>
<table><tr><th>Basis</th><th>Amplitude</th><th>P (ideal)</th><th>Measured ({shots} shots)</th></tr>{ideal_rows}</table>
<p>|\u03b1|\u00b2+|\u03b2|\u00b2 = <b>{abs(a)**2+abs(b)**2:.4f}</b> &nbsp;\u00b7&nbsp; Bloch vector (x,y,z) = ({bx:.2f}, {by:.2f}, {bz:.2f})</p>
<p class="mut">Engine: {escape(engine)}</p></div><div>{svg.bloch_xz(bx,by,bz)}<div class="mut" style="font-size:.8rem">Bloch sphere, x\u2013z plane projection</div></div></div>
<div class="grid2"><div>{ideal}</div><div>{hist}</div></div>
<h3>Equivalent Qiskit code</h3><pre>{escape(qu.qiskit_code(1, ops))}</pre></div>"""
    return page("Bit to Qubit", "/qubit", body)


# -------------------------------------------------------------- COMPARE
def compare(q):
    channel = _s(q, "channel", "bit_flip")
    if channel not in nz.CHANNELS:
        channel = "bit_flip"
    init = _s(q, "init", "zero")
    if init not in ("zero", "plus", "one"):
        init = "zero"
    p = _f(q, "p", 0.2, 0, 1)
    sigma = _f(q, "sigma", 1.0, 0, 5)
    res = nz.experiment(init, channel, p)

    table = [("Bit", "Qubit"), ("0/1", "\u03b1|0\u27e9 + \u03b2|1\u27e9 (\u03b1, \u03b2 complex amplitudes)"), ("NOT", "X"),
             ("Logic operation", "Quantum gate"), ("Output", "Measurement"), ("Noise", "Quantum noise"),
             ("Deterministic", "Probabilistic measurement")]
    tbl = "<table><tr><th>Classical</th><th>Quantum</th></tr>" + "".join(f"<tr><td>{a}</td><td>{b}</td></tr>" for a, b in table[1:]) + "</table>"

    # classical noise
    bits = [1, 0, 1, 1, 0, 0, 1, 0]
    ideal, noisy = tr.noisy_waveform(bits, sigma)
    ber = tr.bit_error_rate(sigma)
    sig_axis = np.linspace(0.05, 3.0, 30)
    ber_curve = [tr.bit_error_rate(s, trials=4000) for s in sig_axis]
    classical = f"""<h3>Classical: <code>V<sub>out</sub> = V<sub>ideal</sub> + n(t)</code></h3>
<form class="ctl" method="get" action="/compare">{num('sigma','Noise \u03c3 (V)',sigma,'0.1')}<input type="hidden" name="channel" value="{channel}"><input type="hidden" name="init" value="{init}"><input type="hidden" name="p" value="{p}"><button>Update</button></form>
<div class="grid2"><div>{svg.waveform(ideal, noisy)}<p class="mut">Red dashed line = logic threshold. Error only if noise crosses it.</p></div>
<div>{svg.line_chart([("Bit error rate", list(sig_axis), ber_curve)], "noise \u03c3 (V)", "bit error rate", ylim=(0, 0.5))}</div></div>
<p>At \u03c3 = {sigma:g} V the simulated bit-error rate is <b>{ber*100:.2f}%</b>. Classical errors are <b>amplitude</b> errors on a definite 0 or 1 and small noise is simply ignored by the threshold.</p>"""

    # quantum noise
    chan_opts = list(nz.CHANNELS.items())
    inits = [("zero", "|0\u27e9"), ("plus", "|+\u27e9 = H|0\u27e9"), ("one", "|1\u27e9")]
    ps, f0 = nz.fidelity_curve("zero", channel)
    _, f1 = nz.fidelity_curve("plus", channel)
    quantum = f"""<h3>Quantum: bit flip, phase flip, depolarizing, amplitude damping</h3>
<form class="ctl" method="get" action="/compare">{select('channel','Noise channel',chan_opts,channel)}{select('init','Initial state',inits,init)}{num('p','Error probability p',p,'0.05','min=0 max=1')}<input type="hidden" name="sigma" value="{sigma}"><button>Apply noise</button></form>
<div class="grid2"><div><table><tr><th>Metric after the channel</th><th>Value</th></tr>
<tr><td>Fidelity with ideal state</td><td class="num">{res['fidelity']:.3f}</td></tr>
<tr><td>P(0) in Z basis</td><td class="num">{res['p0']:.3f}</td></tr><tr><td>P(1) in Z basis</td><td class="num">{res['p1']:.3f}</td></tr>
<tr><td>P(+) in X basis (after H)</td><td class="num">{res['p_plus']:.3f}</td></tr>
<tr><td>Purity Tr(\u03c1\u00b2)</td><td class="num">{res['purity']:.3f}</td></tr><tr><td>Coherence |\u03c1\u2080\u2081|</td><td class="num">{res['coherence']:.3f}</td></tr></table>
<p class="mut">Try <b>phase flip</b> on |0\u27e9: nothing changes (a classical bit can't even have a phase). Now try it on |+\u27e9: fidelity collapses. Bit flip does the opposite.</p></div>
<div>{svg.line_chart([("Start |0>", list(ps), list(f0)), ("Start |+>", list(ps), list(f1))], "error probability p", "fidelity", ylim=(0, 1))}</div></div>"""

    # QEC
    pq = np.linspace(0.0, 0.5, 26)
    ana, sim = nz.repetition_code(pq, trials=8000)
    qec = f"""<h3>Quantum error correction \u2014 3-qubit repetition code</h3>
<p>Encode <code>|0\u27e9\u2192|000\u27e9</code>, <code>|1\u27e9\u2192|111\u27e9</code>, detect with parity checks, correct by majority vote. Logical error
<code>p<sub>L</sub> = 3p\u00b2 \u2212 2p\u00b3</code>. It is the quantum version of triple modular redundancy in electronics, and helps only when p &lt; 0.5.</p>
{svg.line_chart([("No coding (p)", list(pq), list(pq)), ("Analytic p_L", list(pq), list(ana)), ("Simulated p_L", list(pq), list(sim))], "physical error p", "logical error", ylim=(0, 0.5))}"""

    body = f"""<h2>3 \u00b7 Comparison</h2>
<div class="card"><h3 style="margin-top:0">Module D \u2014 Classical vs Quantum</h3>{tbl}</div>
<div class="card">{classical}</div><div class="card">{quantum}</div><div class="card">{qec}</div>
<div class="card"><h3 style="margin-top:0">Investigation: classical vs quantum noise</h3>
<p><b>Classical:</b> information is a voltage level; noise adds a random voltage, and a regenerating threshold restores the bit \u2014 errors are rare unless noise exceeds the margin.<br>
<b>Quantum:</b> information is in continuous amplitudes and relative phase; noise rotates/mixes the state (decoherence), errors accumulate continuously, cannot be thresholded away and cloning/copying to protect data is forbidden \u2014 hence quantum error-correcting codes using parity checks.</p></div>"""
    return page("Comparison", "/compare", body)


# --------------------------------------------------------------- CIRCUIT
SLOTS = 6
GATE_OPTS = [("", "\u2014"), ("x", "X"), ("y", "Y"), ("z", "Z"), ("h", "H"), ("cx", "CNOT"), ("ccx", "Toffoli")]
PRESETS = {
    "bell": ("2", "h0,cx1:0"), "ghz": ("3", "h0,cx1:0,cx2:1"), "not": ("1", "x0"),
    "and": ("3", "x0,x1,ccx2"),
}


def _parse_ops(n, q):
    ops, err = [], []
    for i in range(SLOTS):
        g = _s(q, f"g{i}", "")
        if not g:
            continue
        t = int(_f(q, f"t{i}", 0, 0, n - 1))
        c = int(_f(q, f"c{i}", 0, 0, n - 1))
        if g in ("x", "y", "z", "h"):
            ops.append((g, t, ()))
        elif g == "cx":
            if c == t:
                err.append(f"Step {i+1}: control and target must differ")
            else:
                ops.append((g, t, (c,)))
        elif g == "ccx":
            others = tuple(k for k in range(n) if k != t)
            if n < 3:
                err.append(f"Step {i+1}: Toffoli needs 3 qubits")
            else:
                ops.append((g, t, others))
    return ops, err


def _preset_query(name):
    n, spec = PRESETS[name]
    q = {"n": n}
    for i, token in enumerate(spec.split(",")):
        if token.startswith("cx"):
            tq_, cq = token[2:].split(":")
            q[f"g{i}"], q[f"t{i}"], q[f"c{i}"] = "cx", tq_, cq
        elif token.startswith("ccx"):
            q[f"g{i}"], q[f"t{i}"] = "ccx", token[3:]
        else:
            q[f"g{i}"], q[f"t{i}"] = token[0], token[1:]
    return "&".join(f"{k}={v}" for k, v in q.items())


def circuit(q):
    n = int(_f(q, "n", 2, 1, 3))
    shots = int(_f(q, "shots", 1024, 1, 100000))
    ops, errs = _parse_ops(n, q)
    state, engine = qu.simulate(n, ops)
    p = qu.probabilities(state)
    counts = qu.measure(state, n, shots, seed=11)
    labels = [qu.label(i, n) for i in range(2 ** n)]

    cells = ""
    for i in range(SLOTS):
        cells += f"""<td>{select(f'g{i}','',GATE_OPTS,_s(q,f'g{i}',''))}</td>
<td>{select(f't{i}','',[(k,f'q{k}') for k in range(n)],_s(q,f't{i}','0'))}</td>
<td>{select(f'c{i}','',[(k,f'q{k}') for k in range(n)],_s(q,f'c{i}','0'))}</td></tr><tr>"""
    builder = f"""<form method="get" action="/circuit"><div class="ctl">{select('n','Qubits',[(1,1),(2,2),(3,3)],n)}{num('shots','Shots',shots,'1')}<button>Run circuit</button></div>
<table style="margin-top:10px"><tr><th>Gate (step 1\u20136)</th><th>Target</th><th>Control (CNOT)</th></tr><tr>{cells}</tr></table></form>
<p class="mut">Presets: <a href="/circuit?{_preset_query('bell')}">Bell state</a> \u00b7 <a href="/circuit?{_preset_query('ghz')}">GHZ</a> \u00b7 <a href="/circuit?{_preset_query('not')}">NOT</a> \u00b7 <a href="/circuit?{_preset_query('and')}">AND (Toffoli, inputs 1,1)</a>. Toffoli controls are the other two qubits.</p>"""
    er = "".join(f'<p class="bad">{escape(e)}</p>' for e in errs)
    amps = "".join(f"<tr><td>|{l}\u27e9</td><td class='num'>{qu.fmt_c(state[i])}</td><td class='num'>{p[i]*100:.1f}%</td><td class='num'>{counts.get(l,0)}</td></tr>" for i, l in enumerate(labels))
    lab = f"""<div class="card"><h3 style="margin-top:0">Quantum circuit lab</h3>{builder}{er}
{svg.quantum_circuit(n, ops)}
<div class="grid2"><div><table><tr><th>State</th><th>Amplitude</th><th>P</th><th>Counts</th></tr>{amps}</table><p class="mut">Engine: {escape(engine)}. Labels are |q{n-1}\u2026q0\u27e9 (Qiskit order).</p></div>
<div>{svg.bar_chart(labels,[counts.get(l,0)/shots for l in labels],ylabel='Measured frequency',color='#7c3aed')}</div></div>
<h3>Equivalent Qiskit code</h3><pre>{escape(qu.qiskit_code(n, ops))}</pre></div>"""

    # Level 4: same function both ways
    rows = ""
    for name in ("NOT", "XOR", "AND", "NAND"):
        n_q, _ops, _i, _o, desc = qu.EQUIVALENTS[name]
        combos = [(a, 0) for a in (0, 1)] if name == "NOT" else [(a, b) for a in (0, 1) for b in (0, 1)]
        res = [(a, b, logic.GATES[name](a, b), qu.run_equivalent(name, a, b)[0]) for a, b in combos]
        ok = all(c == d for _, _, c, d in res)
        io = " ; ".join(f"{a}" if name == "NOT" else f"{a}{b}" for a, b, _, _ in res)
        cl = " ; ".join(str(c) for *_, c, _ in res)
        qo = " ; ".join(str(d) for *_, d in res)
        rows += f"<tr><td><b>{name}</b></td><td>{escape(desc)}</td><td class='num'>{io}</td><td class='num'>{cl}</td><td class='num'>{qo}</td><td class='{'ok' if ok else 'bad'}'>{'\u2713 match' if ok else '\u2717'}</td></tr>"
    lvl4 = f"""<div class="card"><h3 style="margin-top:0">Level 4 \u2014 Same logical function, two implementations</h3>
<div class="grid2"><div><div class="flow"><span class="node">Transistors</span><span class="arrow">\u2192</span><span class="node">Logic gates</span><span class="arrow">\u2192</span><span class="node">Digital output</span></div></div>
<div><div class="flow"><span class="node">Qubits</span><span class="arrow">\u2192</span><span class="node">Quantum gates</span><span class="arrow">\u2192</span><span class="node">Measurement</span></div></div></div>
<p class="mut">Classical gates such as AND/XOR destroy information (2 inputs \u2192 1 output). Quantum gates are reversible, so the quantum version keeps the inputs and writes the result onto an extra qubit.</p>
<table><tr><th>Function</th><th>Quantum implementation</th><th>Inputs (AB)</th><th>Classical out</th><th>Quantum out</th><th>Check</th></tr>{rows}</table></div>"""
    return page("Circuit Lab", "/circuit", f"<h2>4 \u00b7 Circuit Lab</h2>{lvl4}{lab}")


# ------------------------------------------------------------------ QUIZ
def quiz_form(q, student="", mode="pre"):
    items = ""
    for i, (topic, text, opts, _, _) in enumerate(qz.QUESTIONS):
        o = "".join(f'<label class="opt" style="flex-direction:row;gap:8px;color:var(--ink)"><input type="radio" name="q{i}" value="{k}" required>{escape(t)}</label>' for k, t in enumerate(opts))
        items += f'<div class="card"><span class="pill">{topic}</span><p><b>Q{i+1}.</b> {escape(text)}</p>{o}</div>'
    modes = [("pre", "Pre-learning assessment"), ("post", "Post-learning assessment")]
    head = f"""<form method="post" action="/quiz"><div class="card"><div class="ctl">
<label>Student ID<input name="student" value="{escape(student)}" required></label>{select('mode','Assessment',modes,mode)}</div>
<p class="mut">Take the <b>pre</b> test before the lessons and the <b>post</b> test after; the page then reports your normalised learning gain.</p></div>"""
    return page("Quiz", "/quiz", f"<h2>Quiz \u2014 assessment</h2>{head}{items}<button>Submit answers</button></form>{summary_block()}")


def summary_block():
    rows = qz.summary()
    if not rows:
        return ""
    fmt = lambda v: "\u2014" if v is None else f"{v:.0f}%"
    t = "".join(f"<tr><td>{escape(r['student'])}</td><td>{fmt(r['pre'])}</td><td>{fmt(r['post'])}</td><td>{'\u2014' if r['gain'] is None else f'{r['gain']:.2f}'}</td></tr>" for r in rows)
    return f"""<div class="card"><h3 style="margin-top:0">Learning-effectiveness record</h3>
<table><tr><th>Student</th><th>Pre</th><th>Post</th><th>Normalised gain g</th></tr>{t}</table>
<p class="mut">g = (post \u2212 pre) / (100 \u2212 pre). Stored locally in <code>data/results.json</code>.</p></div>"""


def quiz_result(form):
    student = (form.get("student", ["anonymous"])[0].strip() or "anonymous")[:40]
    mode = form.get("mode", ["pre"])[0]
    mode = mode if mode in ("pre", "post") else "pre"
    answers = {}
    for i in range(len(qz.QUESTIONS)):
        v = form.get(f"q{i}", [None])[0]
        if v is not None and v.isdigit():
            answers[i] = int(v)
    r = qz.score(answers)
    qz.save_result(student, mode, r["correct"], r["total"])
    pct = 100 * r["correct"] / r["total"]
    review = ""
    for d in r["detail"]:
        opts = ""
        for k, t in enumerate(d["opts"]):
            cls = "good" if k == d["ans"] else ("wrong" if k == d["chosen"] else "")
            mark = " \u2713" if k == d["ans"] else (" \u2717 (your answer)" if k == d["chosen"] else "")
            opts += f'<div class="opt {cls}">{escape(t)}{mark}</div>'
        review += f'<div class="card"><span class="pill">{d["topic"]}</span> <span class="{"ok" if d["ok"] else "bad"}">{"Correct" if d["ok"] else "Incorrect"}</span><p><b>Q{d["i"]+1}.</b> {escape(d["q"])}</p>{opts}<p class="mut">{escape(d["why"])}</p></div>'
    topics = "".join(f"<tr><td>{t}</td><td>{c}/{n}</td><td>{100*c/n:.0f}%</td></tr>" for t, (c, n) in r["topics"].items())
    body = f"""<h2>Result: {r['correct']}/{r['total']} ({pct:.0f}%)</h2>
<div class="card"><p>Student <b>{escape(student)}</b> \u00b7 {mode}-learning assessment saved.</p>
<table><tr><th>Concept area</th><th>Score</th><th>%</th></tr>{topics}</table></div>
{summary_block()}<p><a class="btn" href="/quiz?mode={'post' if mode=='pre' else 'pre'}&student={escape(student)}">Take the {'post' if mode=='pre' else 'pre'} test</a></p>{review}"""
    return page("Quiz result", "/quiz", body)
