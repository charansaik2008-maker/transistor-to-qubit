"""Tiny dependency-free SVG helpers (generated from Python/NumPy data)."""
from html import escape

COLORS = ["#2563eb", "#dc2626", "#16a34a", "#d97706", "#7c3aed"]


def _ticks(lo, hi, n=5):
    return [lo + (hi - lo) * i / n for i in range(n + 1)]


def line_chart(series, xlabel="", ylabel="", w=560, h=300, xlim=None, ylim=None, hline=None):
    """series: list of (name, xs, ys)."""
    ml, mr, mt, mb = 52, 14, 14, 58
    allx = [x for _, xs, _ in series for x in xs]
    ally = [y for _, _, ys in series for y in ys]
    x0, x1 = xlim or (min(allx), max(allx))
    y0, y1 = ylim or (min(ally), max(ally))
    if y1 == y0:
        y1 = y0 + 1
    sx = lambda x: ml + (x - x0) / (x1 - x0) * (w - ml - mr)
    sy = lambda y: h - mb - (y - y0) / (y1 - y0) * (h - mt - mb)
    o = [f'<svg viewBox="0 0 {w} {h}" class="chart" role="img">']
    for t in _ticks(y0, y1):
        o.append(f'<line x1="{ml}" x2="{w-mr}" y1="{sy(t):.1f}" y2="{sy(t):.1f}" class="grid"/>'
                 f'<text x="{ml-6}" y="{sy(t)+4:.1f}" text-anchor="end" class="tick">{t:.2g}</text>')
    for t in _ticks(x0, x1):
        o.append(f'<text x="{sx(t):.1f}" y="{h-mb+16}" text-anchor="middle" class="tick">{t:.3g}</text>')
    if hline is not None:
        o.append(f'<line x1="{ml}" x2="{w-mr}" y1="{sy(hline):.1f}" y2="{sy(hline):.1f}" class="thr"/>')
    for k, (name, xs, ys) in enumerate(series):
        pts = " ".join(f"{sx(x):.1f},{sy(y):.1f}" for x, y in zip(xs, ys))
        o.append(f'<polyline points="{pts}" fill="none" stroke="{COLORS[k % 5]}" stroke-width="2"/>')
        o.append(f'<rect x="{ml+8+k*130}" y="{h-18}" width="10" height="10" fill="{COLORS[k % 5]}"/>'
                 f'<text x="{ml+22+k*130}" y="{h-9}" class="tick">{escape(name)}</text>')
    o.append(f'<text x="{(ml+w-mr)/2}" y="{h-mb+34}" text-anchor="middle" class="axis">{escape(xlabel)}</text>')
    o.append(f'<text transform="rotate(-90 13 {(mt+h-mb)/2})" x="13" y="{(mt+h-mb)/2}" text-anchor="middle" class="axis">{escape(ylabel)}</text>')
    o.append(f'<rect x="{ml}" y="{mt}" width="{w-ml-mr}" height="{h-mt-mb}" fill="none" class="frame"/></svg>')
    return "".join(o)


def bar_chart(labels, values, w=560, h=240, ylabel="Probability", ymax=1.0, color="#2563eb"):
    ml, mr, mt, mb = 48, 12, 14, 40
    n = len(labels)
    bw = (w - ml - mr) / n
    sy = lambda v: h - mb - v / ymax * (h - mt - mb)
    o = [f'<svg viewBox="0 0 {w} {h}" class="chart" role="img">']
    for t in _ticks(0, ymax, 4):
        o.append(f'<line x1="{ml}" x2="{w-mr}" y1="{sy(t):.1f}" y2="{sy(t):.1f}" class="grid"/>'
                 f'<text x="{ml-6}" y="{sy(t)+4:.1f}" text-anchor="end" class="tick">{t:.2g}</text>')
    for i, (lb, v) in enumerate(zip(labels, values)):
        x = ml + i * bw + bw * 0.15
        o.append(f'<rect x="{x:.1f}" y="{sy(v):.1f}" width="{bw*0.7:.1f}" height="{h-mb-sy(v):.1f}" fill="{color}" rx="3"/>'
                 f'<text x="{x+bw*0.35:.1f}" y="{sy(v)-4:.1f}" text-anchor="middle" class="tick">{v:.3f}</text>'
                 f'<text x="{x+bw*0.35:.1f}" y="{h-mb+16}" text-anchor="middle" class="tick">|{escape(lb)}&#x27E9;</text>')
    o.append(f'<text transform="rotate(-90 12 {h/2})" x="12" y="{h/2}" text-anchor="middle" class="axis">{escape(ylabel)}</text></svg>')
    return "".join(o)


def bloch_xz(x, y, z, size=220):
    c, r = size / 2, size / 2 - 22
    px, py = c + x * r, c - z * r
    return (f'<svg viewBox="0 0 {size} {size}" class="bloch" role="img">'
            f'<circle cx="{c}" cy="{c}" r="{r}" fill="none" class="frame"/>'
            f'<line x1="{c-r}" x2="{c+r}" y1="{c}" y2="{c}" class="grid"/><line x1="{c}" x2="{c}" y1="{c-r}" y2="{c+r}" class="grid"/>'
            f'<text x="{c}" y="14" text-anchor="middle" class="tick">|0&#x27E9;</text>'
            f'<text x="{c}" y="{size-5}" text-anchor="middle" class="tick">|1&#x27E9;</text>'
            f'<text x="{size-4}" y="{c-4}" text-anchor="end" class="tick">+x</text>'
            f'<line x1="{c}" y1="{c}" x2="{px:.1f}" y2="{py:.1f}" stroke="#dc2626" stroke-width="2.5"/>'
            f'<circle cx="{px:.1f}" cy="{py:.1f}" r="5" fill="#dc2626"/></svg>')


def waveform(ideal, noisy, vcc=5.0, w=620, h=240):
    n = len(ideal)
    xs = list(range(n))
    return line_chart([("Ideal", xs, list(ideal)), ("Noisy Vout", xs, list(noisy))],
                      "sample (time)", "Vout (V)", w, h, ylim=(min(min(noisy), -0.5), max(max(noisy), vcc + 0.5)),
                      hline=vcc / 2)


def quantum_circuit(n, ops, w_step=62):
    """Draw an n-qubit circuit diagram with a measurement box at the end."""
    L, gap = 46, 44
    W = L + w_step * (len(ops) + 2) + 10
    H = gap * n + 20
    y = lambda q: 24 + (n - 1 - q) * gap if False else 24 + q * gap  # q0 on top
    o = [f'<svg viewBox="0 0 {W} {H}" class="circuit" role="img">']
    for q in range(n):
        o.append(f'<text x="4" y="{y(q)+4}" class="tick">q{q}</text>'
                 f'<line x1="{L-6}" x2="{W-10}" y1="{y(q)}" y2="{y(q)}" class="wire"/>')
    for k, (name, t, ctrls) in enumerate(ops):
        cx = L + w_step * (k + 0.5) + 8
        if ctrls:
            ys = [y(c) for c in ctrls] + [y(t)]
            o.append(f'<line x1="{cx}" x2="{cx}" y1="{min(ys)}" y2="{max(ys)}" class="wire2"/>')
            for c in ctrls:
                o.append(f'<circle cx="{cx}" cy="{y(c)}" r="5" class="ctrl"/>')
            o.append(f'<circle cx="{cx}" cy="{y(t)}" r="12" class="tgt"/>'
                     f'<line x1="{cx-12}" x2="{cx+12}" y1="{y(t)}" y2="{y(t)}" class="wire2"/>'
                     f'<line x1="{cx}" x2="{cx}" y1="{y(t)-12}" y2="{y(t)+12}" class="wire2"/>')
        else:
            o.append(f'<rect x="{cx-14}" y="{y(t)-14}" width="28" height="28" rx="4" class="box"/>'
                     f'<text x="{cx}" y="{y(t)+5}" text-anchor="middle" class="gate">{name.upper()}</text>')
    mx = L + w_step * (len(ops) + 1) + 8
    for q in range(n):
        o.append(f'<rect x="{mx-14}" y="{y(q)-14}" width="28" height="28" rx="4" class="meas"/>'
                 f'<path d="M{mx-8},{y(q)+6} a8,8 0 0 1 16,0" fill="none" class="mline"/>'
                 f'<line x1="{mx}" y1="{y(q)+6}" x2="{mx+6}" y2="{y(q)-6}" class="mline"/>')
    o.append("</svg>")
    return "".join(o)
