"""Module B: logic-gate simulator + NAND-only (transistor-level) constructions."""

GATES = {
    "NOT":  lambda a, b=0: 1 - a,
    "AND":  lambda a, b: a & b,
    "OR":   lambda a, b: a | b,
    "NAND": lambda a, b: 1 - (a & b),
    "NOR":  lambda a, b: 1 - (a | b),
    "XOR":  lambda a, b: a ^ b,
}

# Number of transistors in a standard static CMOS implementation
CMOS_TRANSISTORS = {"NOT": 2, "NAND": 4, "NOR": 4, "AND": 6, "OR": 6, "XOR": 12}


def truth_table(name):
    if name == "NOT":
        return [((a,), GATES["NOT"](a)) for a in (0, 1)]
    return [((a, b), GATES[name](a, b)) for a in (0, 1) for b in (0, 1)]


def nand(a, b):
    return 1 - (a & b)


def from_nand(name, a, b=0):
    """Build each gate using only NAND (the universal gate) - proves universality."""
    if name == "NOT":
        return nand(a, a)
    if name == "AND":
        return nand(nand(a, b), nand(a, b))
    if name == "OR":
        return nand(nand(a, a), nand(b, b))
    if name == "NOR":
        o = nand(nand(a, a), nand(b, b))
        return nand(o, o)
    if name == "XOR":
        t = nand(a, b)
        return nand(nand(a, t), nand(b, t))
    return nand(a, b)


NAND_COUNT = {"NOT": 1, "AND": 2, "OR": 3, "NAND": 1, "NOR": 4, "XOR": 4}
