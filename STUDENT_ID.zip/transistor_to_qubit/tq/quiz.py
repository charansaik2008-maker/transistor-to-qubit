"""Pre-/post-learning assessment: question bank, scoring and result storage."""
import json
import time
from pathlib import Path

RESULTS = Path(__file__).resolve().parent.parent / "data" / "results.json"

# (topic, question, options, correct index, explanation)
QUESTIONS = [
    ("Transistor", "In the Input -> Transistor -> LED circuit, what happens when Vin is below the base-emitter threshold (~0.7 V)?",
     ["Transistor saturates, LED ON", "Transistor is in cut-off, LED OFF", "LED glows at half brightness", "Collector current is infinite"], 1,
     "Below ~0.7 V no base current flows, so Ic = 0 and the transistor acts as an open switch (cut-off)."),
    ("Transistor", "Which operating regions make a transistor behave as a digital switch?",
     ["Active only", "Cut-off and saturation", "Breakdown and active", "Saturation only"], 1,
     "Digital logic drives the transistor between cut-off (OFF) and saturation (ON), avoiding the active region except while switching."),
    ("Logic", "A transistor (common-emitter) inverter gives Vout = high when Vin is:",
     ["High", "Low", "Exactly Vcc/2", "Never"], 1,
     "Low input -> cut-off -> no drop across Rc -> Vout = Vcc (logic 1). That is a NOT gate."),
    ("Logic", "Which gate is 'universal' so every other classical gate can be built from it?",
     ["XOR", "AND", "NAND", "OR"], 2, "NAND (and NOR) are universal. Our NAND-only constructions in the Transistor section demonstrate this."),
    ("Qubit", "X|0> equals:",
     ["|0>", "|1>", "(|0>+|1>)/sqrt2", "-|0>"], 1, "The X gate is the quantum NOT / bit flip: X|0> = |1>, X|1> = |0>."),
    ("Qubit", "A qubit state is alpha|0> + beta|1>. The normalisation condition is:",
     ["alpha + beta = 1", "|alpha|^2 + |beta|^2 = 1", "alpha*beta = 1", "|alpha| = |beta|"], 1,
     "Probabilities are |alpha|^2 and |beta|^2 and they must add to 1."),
    ("Qubit", "Measuring H|0> many times gives:",
     ["Always 0", "Always 1", "About 50% 0 and 50% 1", "Random numbers outside {0,1}"], 2,
     "H|0> = (|0>+|1>)/sqrt2 so P(0)=P(1)=50%; each single measurement still gives a definite 0 or 1."),
    ("Qubit", "Which statement about a classical bit vs a qubit is correct?",
     ["A qubit is just a bit with noise", "A qubit can be in a superposition of 0 and 1 before measurement", "A bit can hold complex amplitudes", "Measurement does not change a qubit"], 1,
     "Superposition with complex probability amplitudes is the key new feature; measurement collapses the state."),
    ("Circuit", "Which quantum gate is the reversible analogue of the classical XOR gate?",
     ["Hadamard", "Z", "CNOT", "S"], 2, "CNOT leaves A unchanged and replaces the target B with A xor B."),
    ("Circuit", "Starting from |00>, applying H on qubit 0 and then CNOT (control 0, target 1) produces:",
     ["|11>", "(|00>+|11>)/sqrt2 (Bell state)", "(|01>+|10>)/sqrt2", "|00>"], 1,
     "This is the Bell (entangled) state; outcomes are 00 or 11 with 50% each."),
    ("Noise", "Classical transistor noise Vout = Videal + n(t) causes a bit error when:",
     ["Noise is exactly zero", "Noise pushes Vout across the logic threshold", "Vcc is increased", "Temperature is 0 K"], 1,
     "If |n(t)| exceeds the noise margin the receiving gate reads the wrong logic level."),
    ("Noise", "Which error does a Z gate model, and why can't a classical bit suffer it?",
     ["Bit flip; bits have no 0/1", "Phase flip; a classical bit has no phase between 0 and 1", "Depolarising; bits have no probabilities", "Measurement; bits are never read"], 1,
     "Phase flips change the sign of the |1> amplitude - information that only exists for superpositions."),
    ("Noise", "The 3-qubit repetition code (like triple modular redundancy) lowers the logical error rate from p to roughly:",
     ["p", "3p^2 - 2p^3", "p^3 + 1", "sqrt(p)"], 1,
     "Majority vote fails only if 2 or 3 qubits flip: 3p^2(1-p) + p^3 = 3p^2 - 2p^3."),
]


def score(answers):
    """answers: {question index: chosen option index}. Returns detail + totals."""
    detail, correct = [], 0
    topics = {}
    for i, (topic, q, opts, ans, why) in enumerate(QUESTIONS):
        chosen = answers.get(i)
        ok = chosen == ans
        correct += ok
        t = topics.setdefault(topic, [0, 0])
        t[0] += ok
        t[1] += 1
        detail.append(dict(i=i, topic=topic, q=q, opts=opts, ans=ans, chosen=chosen, ok=ok, why=why))
    return dict(detail=detail, correct=correct, total=len(QUESTIONS), topics=topics)


def _load():
    try:
        return json.loads(RESULTS.read_text())
    except Exception:
        return []


def save_result(student, mode, correct, total):
    RESULTS.parent.mkdir(exist_ok=True)
    rows = _load()
    rows.append(dict(student=student, mode=mode, correct=correct, total=total,
                     time=time.strftime("%Y-%m-%d %H:%M")))
    RESULTS.write_text(json.dumps(rows, indent=2))


def summary():
    """Latest pre/post per student + normalised gain g = (post-pre)/(100-pre)."""
    latest = {}
    for r in _load():
        latest.setdefault(r["student"], {})[r["mode"]] = 100 * r["correct"] / r["total"]
    out = []
    for s, d in latest.items():
        pre, post = d.get("pre"), d.get("post")
        gain = None
        if pre is not None and post is not None:
            gain = (post - pre) / (100 - pre) if pre < 100 else 0.0
        out.append(dict(student=s, pre=pre, post=post, gain=gain))
    return out
