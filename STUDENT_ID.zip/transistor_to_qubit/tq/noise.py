"""Noise models: classical transistor noise vs quantum noise (density matrices)."""
import numpy as np
from .quantum import MATRICES

I2 = np.eye(2, dtype=complex)
X, Y, Z = MATRICES["x"], MATRICES["y"], MATRICES["z"]


def kraus(channel, p):
    if channel == "bit_flip":
        return [np.sqrt(1 - p) * I2, np.sqrt(p) * X]
    if channel == "phase_flip":
        return [np.sqrt(1 - p) * I2, np.sqrt(p) * Z]
    if channel == "depolarizing":
        return [np.sqrt(1 - p) * I2] + [np.sqrt(p / 3) * P for P in (X, Y, Z)]
    if channel == "amp_damping":  # T1 relaxation, gamma = p
        return [np.array([[1, 0], [0, np.sqrt(1 - p)]], dtype=complex),
                np.array([[0, np.sqrt(p)], [0, 0]], dtype=complex)]
    raise ValueError(channel)


CHANNELS = {
    "bit_flip": "Bit-flip error (X with prob. p)",
    "phase_flip": "Phase-flip error (Z with prob. p)",
    "depolarizing": "Depolarizing noise",
    "amp_damping": "Amplitude damping (T1 decoherence)",
}


def apply_channel(rho, channel, p):
    return sum(K @ rho @ K.conj().T for K in kraus(channel, p))


def initial(name):
    if name == "plus":
        return MATRICES["h"] @ np.array([1, 0], dtype=complex)
    if name == "one":
        return np.array([0, 1], dtype=complex)
    return np.array([1, 0], dtype=complex)


def experiment(init, channel, p):
    psi = initial(init)
    rho = np.outer(psi, psi.conj())
    out = apply_channel(rho, channel, p)
    plus = initial("plus")
    return dict(
        fidelity=float((psi.conj() @ out @ psi).real),
        p0=float(out[0, 0].real), p1=float(out[1, 1].real),
        p_plus=float((plus.conj() @ out @ plus).real),
        purity=float(np.trace(out @ out).real),
        coherence=float(abs(out[0, 1])),
    )


def fidelity_curve(init, channel, n=41):
    ps = np.linspace(0, 1, n)
    return ps, np.array([experiment(init, channel, p)["fidelity"] for p in ps])


def repetition_code(ps, trials=40000, seed=3):
    """3-qubit bit-flip code: logical error = majority vote fails."""
    rng = np.random.default_rng(seed)
    analytic = 3 * ps ** 2 - 2 * ps ** 3
    sim = np.array([np.mean((rng.random((trials, 3)) < p).sum(axis=1) >= 2) for p in ps])
    return analytic, sim
