"""Level 1 / Level 2 / Module A: transistor switching, NOT gate, transistor noise.

Uses a simple piece-wise NPN BJT model (cut-off / active / saturation):
    Vin --Rb--> Base ;  Vcc --(LED)--Rc--> Collector ;  Emitter -> GND
"""
import numpy as np


def led_switch(vin, vcc=5.0, rb=10_000.0, rc=330.0, beta=100.0, vth=0.7,
               vce_sat=0.2, led_vf=2.0):
    """Input -> Transistor -> LED circuit. Returns a dict of operating values."""
    if vin <= vth:
        region, ib, ic = "Cut-off", 0.0, 0.0
    else:
        ib = (vin - vth) / rb
        ic_active = beta * ib
        ic_sat = max((vcc - led_vf - vce_sat) / rc, 0.0)
        if ic_active >= ic_sat:
            region, ic = "Saturation", ic_sat
        else:
            region, ic = "Active", ic_active
    vce = max(vcc - led_vf - ic * rc, 0.0) if region != "Saturation" else vce_sat
    ic_sat = max((vcc - led_vf - vce_sat) / rc, 1e-12)
    brightness = min(ic / ic_sat, 1.0)
    return dict(vin=vin, region=region, ib=ib, ic=ic, vce=vce,
                brightness=brightness, led_on=brightness > 0.5,
                bit=1 if brightness > 0.5 else 0)


def inverter(vin, vcc=5.0, rb=10_000.0, rc=1_000.0, beta=100.0, vth=0.7,
             vce_sat=0.2):
    """Transistor NOT gate (resistor-transistor logic). Returns Vout (V)."""
    if vin <= vth:
        return vcc
    ib = (vin - vth) / rb
    ic = beta * ib
    return max(vcc - ic * rc, vce_sat)


def transfer_curve(vcc=5.0, rb=10_000.0, rc=1_000.0, beta=100.0, vth=0.7, n=101):
    v = np.linspace(0, vcc, n)
    return v, np.array([inverter(x, vcc, rb, rc, beta, vth) for x in v])


def to_bit(v, vcc=5.0):
    return 1 if v > vcc / 2 else 0


def noise_margins(vcc=5.0, rb=10_000.0, rc=1_000.0, beta=100.0, vth=0.7):
    """Noise margin of the NOT gate output levels w.r.t. the logic threshold Vcc/2."""
    vout_high = inverter(0.0, vcc, rb, rc, beta, vth)
    vout_low = inverter(vcc, vcc, rb, rc, beta, vth)
    half = vcc / 2
    return dict(vout_high=vout_high, vout_low=vout_low,
                nm_high=vout_high - half, nm_low=half - vout_low)


def noisy_waveform(bits, sigma, vcc=5.0, samples_per_bit=20, seed=1,
                   v_low=0.2):
    """Vout = V_ideal + n(t) for a bit stream (Gaussian noise)."""
    rng = np.random.default_rng(seed)
    ideal = np.repeat([vcc if b else v_low for b in bits], samples_per_bit)
    return ideal, ideal + rng.normal(0, sigma, ideal.size)


def bit_error_rate(sigma, vcc=5.0, trials=20000, seed=7, v_low=0.2):
    """Monte-Carlo probability that noise flips a bit at the Vcc/2 threshold."""
    rng = np.random.default_rng(seed)
    bits = rng.integers(0, 2, trials)
    v = np.where(bits == 1, vcc, v_low) + rng.normal(0, sigma, trials)
    return float(np.mean((v > vcc / 2).astype(int) != bits))
