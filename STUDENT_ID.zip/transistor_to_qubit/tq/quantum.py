"""Modules C/D: quantum simulator built on Qiskit (with a NumPy cross-check).

Convention (same as Qiskit): qubit 0 is the right-most bit of a basis label,
i.e. |q2 q1 q0>.  Every circuit is simulated with NumPy, and, when Qiskit is
installed, ALSO with qiskit.quantum_info.Statevector; the two are compared.
"""
import numpy as np

try:  # Qiskit is the primary engine
    from qiskit import QuantumCircuit
    from qiskit.quantum_info import Statevector
    HAVE_QISKIT = True
    import qiskit
    QISKIT_VERSION = qiskit.__version__
except Exception:  # pragma: no cover - fallback so the site still runs
    HAVE_QISKIT = False
    QISKIT_VERSION = None

SQ2 = 1 / np.sqrt(2)
MATRICES = {
    "x": np.array([[0, 1], [1, 0]], dtype=complex),
    "y": np.array([[0, -1j], [1j, 0]], dtype=complex),
    "z": np.array([[1, 0], [0, -1]], dtype=complex),
    "h": SQ2 * np.array([[1, 1], [1, -1]], dtype=complex),
    "s": np.array([[1, 0], [0, 1j]], dtype=complex),
    "t": np.array([[1, 0], [0, np.exp(1j * np.pi / 4)]], dtype=complex),
}
# op = (name, target, controls)   names: x y z h s t cx ccx
BASE = {"cx": "x", "ccx": "x"}


def _full_unitary(n, name, target, controls):
    U = MATRICES[BASE.get(name, name)]
    dim = 2 ** n
    M = np.zeros((dim, dim), dtype=complex)
    for i in range(dim):
        if all((i >> c) & 1 for c in controls):
            tb = (i >> target) & 1
            for b in (0, 1):
                j = (i & ~(1 << target)) | (b << target)
                M[j, i] += U[b, tb]
        else:
            M[i, i] = 1
    return M


def numpy_state(n, ops, init=None):
    psi = np.zeros(2 ** n, dtype=complex)
    psi[0] = 1
    if init is not None:
        psi = np.array(init, dtype=complex)
    for name, target, controls in ops:
        psi = _full_unitary(n, name, target, controls) @ psi
    return psi


def build_qiskit_circuit(n, ops):
    qc = QuantumCircuit(n)
    for name, target, controls in ops:
        if name in ("x", "y", "z", "h", "s", "t"):
            getattr(qc, name)(target)
        elif name == "cx":
            qc.cx(controls[0], target)
        elif name == "ccx":
            qc.ccx(controls[0], controls[1], target)
    return qc


def simulate(n, ops, init=None):
    """Return (statevector, engine_label).  `init` only used by the 1-qubit lab."""
    ref = numpy_state(n, ops, init)
    if HAVE_QISKIT:
        try:
            if init is None:
                qsv = Statevector.from_instruction(build_qiskit_circuit(n, ops)).data
            else:
                sv = Statevector(np.array(init, dtype=complex))
                qsv = sv.evolve(build_qiskit_circuit(n, ops)).data
            ok = np.allclose(qsv, ref, atol=1e-9)
            return np.array(qsv), f"Qiskit {QISKIT_VERSION} (cross-checked with NumPy: {'match' if ok else 'MISMATCH'})"
        except Exception as e:  # pragma: no cover
            return ref, f"NumPy fallback ({type(e).__name__})"
    return ref, "NumPy simulator (Qiskit not installed)"


def qiskit_code(n, ops, measure=True):
    lines = ["from qiskit import QuantumCircuit",
             "from qiskit.quantum_info import Statevector", "",
             f"qc = QuantumCircuit({n})"]
    for name, target, controls in ops:
        args = ", ".join(str(q) for q in (*controls, target))
        lines.append(f"qc.{name}({args})")
    lines += ["", "state = Statevector.from_instruction(qc)",
              "print(state.probabilities_dict())      # ideal probabilities"]
    if measure:
        lines.append("print(state.sample_counts(1024))      # simulated measurement")
    return "\n".join(lines)


def probabilities(state):
    p = np.abs(state) ** 2
    return p / p.sum()


def label(i, n):
    return format(i, f"0{n}b")


def measure(state, n, shots=1024, seed=None):
    rng = np.random.default_rng(seed)
    counts = rng.multinomial(shots, probabilities(state))
    return {label(i, n): int(c) for i, c in enumerate(counts) if c}


def bloch(state):
    a, b = state[0], state[1]
    return (float(2 * (np.conj(a) * b).real), float(2 * (np.conj(a) * b).imag),
            float(abs(a) ** 2 - abs(b) ** 2))


def single_qubit_state(theta_deg, phi_deg):
    th, ph = np.radians(theta_deg), np.radians(phi_deg)
    return np.array([np.cos(th / 2), np.exp(1j * ph) * np.sin(th / 2)], dtype=complex)


def fmt_c(z, nd=3):
    z = complex(z)
    re, im = round(z.real, nd), round(z.imag, nd)
    if im == 0:
        return f"{re:g}"
    if re == 0:
        return f"{im:g}i"
    return f"{re:g}{'+' if im >= 0 else '-'}{abs(im):g}i"


# ---- Level 4: same logical function, classical vs reversible quantum circuit
EQUIVALENTS = {
    # classical gate : (qubits, ops, input qubits, output qubit, description)
    "NOT":  (1, [("x", 0, ())], [0], 0, "X gate flips |0>,|1>"),
    "XOR":  (2, [("cx", 1, (0,))], [0, 1], 1, "CNOT: target becomes A xor B"),
    "AND":  (3, [("ccx", 2, (0, 1))], [0, 1], 2, "Toffoli (CCX): target becomes A and B"),
    "NAND": (3, [("ccx", 2, (0, 1)), ("x", 2, ())], [0, 1], 2, "Toffoli followed by X"),
}


def run_equivalent(name, a, b=0):
    """Prepare |a b 0>, run the quantum gate(s), read the output qubit."""
    n, ops, inputs, out, _ = EQUIVALENTS[name]
    prep = []
    vals = (a, b)
    for q, v in zip(inputs, vals):
        if v:
            prep.append(("x", q, ()))
    state, _eng = simulate(n, prep + ops)
    p = probabilities(state)
    idx = int(np.argmax(p))
    return (idx >> out) & 1, float(p.max())
