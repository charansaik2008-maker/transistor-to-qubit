"""Shared HTML shell + CSS (pure Python string templates, no JS frameworks)."""
from html import escape

NAV = [("/", "Home"), ("/transistor", "1. Transistor"), ("/qubit", "2. Bit \u2192 Qubit"),
       ("/compare", "3. Comparison"), ("/circuit", "4. Circuit Lab"), ("/quiz", "Quiz")]

CSS = """
:root{--bg:#f7f8fb;--card:#fff;--ink:#14213d;--mut:#5b6478;--line:#dde2ee;--acc:#2563eb;--acc2:#7c3aed;--ok:#16a34a;--bad:#dc2626}
@media(prefers-color-scheme:dark){:root{--bg:#0e1424;--card:#172038;--ink:#e8ecf7;--mut:#9aa6c1;--line:#2a3558;--acc:#6ea0ff;--acc2:#b39bff}}
*{box-sizing:border-box}body{margin:0;font:16px/1.55 system-ui,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--ink)}
header{background:linear-gradient(120deg,#1e3a8a,#6d28d9);color:#fff;padding:18px 20px 0}
header h1{margin:0;font-size:1.35rem}header p{margin:2px 0 12px;opacity:.85;font-size:.9rem}
nav{display:flex;flex-wrap:wrap;gap:4px}nav a{color:#fff;text-decoration:none;padding:8px 14px;border-radius:8px 8px 0 0;opacity:.8;font-size:.95rem}
nav a.on,nav a:hover{background:var(--bg);color:var(--ink);opacity:1}
main{max-width:980px;margin:0 auto;padding:22px 16px 60px}
h2{margin:.2em 0 .4em}h3{margin:1.2em 0 .3em}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px;margin:16px 0}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px}
.mut{color:var(--mut)}.ok{color:var(--ok);font-weight:600}.bad{color:var(--bad);font-weight:600}
.pill{display:inline-block;padding:2px 10px;border-radius:99px;background:var(--acc);color:#fff;font-size:.8rem}
.pill.off{background:var(--mut)}.pill.on{background:var(--ok)}
form.ctl{display:flex;flex-wrap:wrap;gap:12px;align-items:end}
label{display:flex;flex-direction:column;font-size:.82rem;color:var(--mut);gap:3px}
input,select,button,textarea{font:inherit;padding:7px 9px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--ink)}
input[type=number]{width:110px}input[type=radio]{padding:0}
button,.btn{background:var(--acc);color:#fff;border:0;cursor:pointer;padding:8px 16px;text-decoration:none;border-radius:8px;display:inline-block}
.btn.sec{background:transparent;color:var(--acc);border:1px solid var(--acc)}
table{border-collapse:collapse;width:100%;font-size:.93rem}th,td{padding:7px 10px;border-bottom:1px solid var(--line);text-align:left}
th{color:var(--mut);font-weight:600}td.num{font-variant-numeric:tabular-nums}
code,pre{font-family:ui-monospace,Consolas,monospace;font-size:.86rem}pre{background:var(--bg);border:1px solid var(--line);padding:12px;border-radius:8px;overflow:auto}
svg.chart{width:100%;max-width:620px;height:auto}svg.circuit{max-width:100%;height:auto;min-height:90px}svg.bloch{width:220px;height:220px}
svg .grid{stroke:var(--line);stroke-width:1}svg .frame{stroke:var(--mut);stroke-width:1;fill:none}svg .tick{fill:var(--mut);font-size:10.5px}
svg .axis{fill:var(--ink);font-size:11.5px}svg .thr{stroke:var(--bad);stroke-dasharray:5 4}svg .wire{stroke:var(--mut);stroke-width:1.6}
svg .wire2{stroke:var(--ink);stroke-width:2}svg .box{fill:var(--acc);}svg .gate{fill:#fff;font-weight:700;font-size:13px}
svg .ctrl{fill:var(--ink)}svg .tgt{fill:var(--card);stroke:var(--ink);stroke-width:2}svg .meas{fill:var(--card);stroke:var(--mut)}svg .mline{stroke:var(--ink);fill:none;stroke-width:1.4}
.led{width:46px;height:46px;border-radius:50%;display:inline-block;border:3px solid var(--line);vertical-align:middle}
.flow{display:flex;flex-wrap:wrap;gap:8px;align-items:center;font-weight:600}.flow span.arrow{color:var(--mut)}
.flow .node{background:var(--bg);border:1px solid var(--line);padding:6px 12px;border-radius:8px}
.opt{display:block;padding:6px 10px;border-radius:8px;border:1px solid transparent}.opt:hover{background:var(--bg)}
.good{background:rgba(22,163,74,.13);border-color:var(--ok)}.wrong{background:rgba(220,38,38,.12);border-color:var(--bad)}
footer{text-align:center;color:var(--mut);font-size:.82rem;padding:20px}
"""


def page(title, active, body, sub="From Transistors to Qubits \u2014 EDC Assignment #2"):
    links = "".join(f'<a href="{h}" class="{"on" if h == active else ""}">{escape(t)}</a>' for h, t in NAV)
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{escape(title)} \u00b7 Transistor-to-Qubit</title>
<style>{CSS}</style></head><body><header><h1>Transistor-to-Qubit Learning Framework</h1><p>{escape(sub)}</p>
<nav>{links}</nav></header><main>{body}</main>
<footer>Built with Python \u00b7 NumPy \u00b7 Qiskit &nbsp;|&nbsp; Academic project</footer></body></html>"""


def num(name, label, val, step="any", extra=""):
    return f'<label>{escape(label)}<input type="number" name="{name}" value="{val}" step="{step}" {extra}></label>'


def select(name, label, options, current):
    o = "".join(f'<option value="{escape(str(v))}" {"selected" if str(v) == str(current) else ""}>{escape(str(t))}</option>' for v, t in options)
    return f'<label>{escape(label)}<select name="{name}">{o}</select></label>'
